package com.ruru.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.util.*;

public class MainActivity extends Activity {
    final int BG = Color.rgb(9,7,16), CARD = Color.rgb(24,19,36), PURPLE = Color.rgb(151,93,255);
    final int WHITE = Color.WHITE, MUTED = Color.rgb(183,174,199);
    LinearLayout root, body;
    String current = "Home";

    @Override public void onCreate(Bundle b) { super.onCreate(b); show("Home"); }

    GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    void pad(View v, int p) { v.setPadding(p,p,p,p); }
    void gap(LinearLayout parent, int h) { View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1,h)); }
    TextView button(String label, Runnable action) {
        TextView b = text(label, 14, WHITE, true); b.setGravity(Gravity.CENTER); b.setPadding(16,14,16,14);
        b.setBackground(shape(PURPLE, 18)); b.setOnClickListener(v -> action.run()); return b;
    }
    void show(String page) {
        current = page;
        root = column(); root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout header = row(); header.setPadding(20,22,20,16);
        TextView logo = text("RURU", 25, WHITE, true);
        TextView tag = text("  VIDEO • CONNECT • EARN", 10, MUTED, true);
        header.addView(logo); header.addView(tag); root.addView(header);
        ScrollView scroll = new ScrollView(this);
        body = column(); body.setPadding(18,8,18,24); scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        render(page);
        LinearLayout nav = row(); nav.setPadding(6,8,6,10); nav.setBackgroundColor(Color.rgb(17,13,25));
        String[] tabs = {"Home","Hosts","Register","Agency","Wallet"};
        for (String tab: tabs) {
            TextView n = text(tab, 11, current.equals(tab)?PURPLE:MUTED, true);
            n.setGravity(Gravity.CENTER); n.setPadding(5,14,5,14);
            n.setOnClickListener(v -> show(tab));
            nav.addView(n, new LinearLayout.LayoutParams(0,-2,1));
        }
        root.addView(nav);
    }
    void title(String s) { body.addView(text(s,22,WHITE,true)); gap(body,8); }
    void subtitle(String s) { body.addView(text(s,13,MUTED,false)); gap(body,14); }
    LinearLayout card(String heading, String detail) {
        LinearLayout c = column(); c.setPadding(16,16,16,16); c.setBackground(shape(CARD,20));
        c.addView(text(heading,16,WHITE,true)); gap(c,6); c.addView(text(detail,13,MUTED,false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12; body.addView(c,lp); return c;
    }
    EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextColor(WHITE); e.setHintTextColor(MUTED);
        e.setHint(hint); e.setTextSize(14); e.setInputType(type); e.setPadding(14,12,14,12);
        e.setBackground(shape(CARD,14)); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=10; body.addView(e,lp); return e;
    }
    void render(String p) {
        if (p.equals("Home")) {
            title("Meet. Talk. Connect.");
            subtitle("Discover creators and connect through private video experiences.");
            LinearLayout hero = card("Welcome to RURU", "A new community for real conversations, creators and agencies.");
            hero.addView(button("Explore Hosts", () -> show("Hosts")));
            card("For Hosts", "Create your profile, complete verification and manage your creator journey.");
            card("For Agencies", "Build your team, invite eligible hosts and track performance.");
            body.addView(button("Register as a Host", () -> show("Register")));
            gap(body,10);
            body.addView(button("Agency Registration", () -> show("Agency")));
            gap(body,10);
            body.addView(button("Admin Demo", () -> show("Admin")));
            note("Demo build: profiles and forms are local preview only.");
        } else if (p.equals("Hosts")) {
            title("Featured Hosts"); subtitle("Sample profiles for layout preview. These are not real users.");
            String[] names={"Aanya • India","Mira • India","Riya • India"};
            for(String n:names) {
                LinearLayout c=card("✦  "+n,"Available for a friendly conversation • Sample profile");
                c.addView(button("Open Call Preview",()->callPreview(n)));
            }
        } else if (p.equals("Register")) {
            title("Host Registration"); subtitle("18+ only. Submit accurate information. Do not upload identity documents in this demo.");
            EditText name=field("Full name",InputType.TYPE_CLASS_TEXT);
            EditText age=field("Age (18+)",InputType.TYPE_CLASS_NUMBER);
            EditText city=field("City",InputType.TYPE_CLASS_TEXT);
            EditText phone=field("Mobile number",InputType.TYPE_CLASS_PHONE);
            EditText intro=field("Short introduction",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            body.addView(button("Submit Demo Registration",()->{
                if(name.getText().length()==0 || age.getText().length()==0 || city.getText().length()==0 || phone.getText().length()==0) {
                    toast("Please fill name, age, city and mobile."); return;
                }
                int a; try { a=Integer.parseInt(age.getText().toString()); } catch(Exception ex){a=0;}
                if(a<18){toast("Only adults aged 18+ can register.");return;}
                toast("Demo form submitted on this device. No data was sent to a server.");
            }));
        } else if (p.equals("Agency")) {
            title("Agency Partner"); subtitle("Apply to manage a host team. Approval and commission terms require a real backend and signed agreement.");
            EditText agency=field("Agency / business name",InputType.TYPE_CLASS_TEXT);
            EditText owner=field("Owner name",InputType.TYPE_CLASS_TEXT);
            EditText contact=field("Email or mobile",InputType.TYPE_CLASS_TEXT);
            EditText size=field("Expected host team size",InputType.TYPE_CLASS_NUMBER);
            body.addView(button("Submit Demo Application",()->{
                if(agency.getText().length()==0 || owner.getText().length()==0 || contact.getText().length()==0) toast("Please complete required fields.");
                else toast("Demo application preview only. Not sent to RURU servers.");
            }));
        } else if (p.equals("Wallet")) {
            title("Wallet"); subtitle("Demo wallet — no real money or payments.");
            card("0 RURU Coins","Your demo balance");
            card("Withdrawals","Real payouts are not enabled in this prototype.");
            card("Payment safety","Never pay a registration fee or share OTPs without verifying the platform.");
        } else if (p.equals("Admin")) {
            title("Admin Dashboard"); subtitle("Preview only. This screen is not protected by a real admin login yet.");
            card("Host Applications","0 pending • Connect a secure backend to review submissions.");
            card("Agency Applications","0 pending • Role-based access is not implemented.");
            card("Payout Requests","Disabled until payment compliance and verification are implemented.");
            card("Reports","Demo analytics placeholder.");
            body.addView(button("Back to Home",()->show("Home")));
        }
    }
    void callPreview(String n) {
        new android.app.AlertDialog.Builder(this).setTitle("Private Call Preview")
            .setMessage("This is a screen-flow demo for "+n+". Live video calling is not connected yet.")
            .setPositiveButton("OK",(d,w)->{}).show();
    }
    void note(String s) { gap(body,16); body.addView(text(s,11,MUTED,false)); }
    void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
