# RURU Android MVP 1.0

A native Android starter project for the RURU dark-purple/black video-chat and agency concept.

## Included
- Home screen and bottom navigation
- Sample host directory
- Host registration form with an 18+ age check
- Agency application form
- Demo wallet
- Admin dashboard preview
- Private-call flow preview

## Important limitations
This is a front-end prototype. Forms are not sent to a server and data is not persisted. It does **not** include real authentication, live video/audio, chat, coin purchases, withdrawals, agency commissions, admin security, moderation, or production hosting. The sample host profiles are fictional placeholders.

## Build in Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder as an existing project.
3. Allow Gradle sync (requires internet to download Android Gradle Plugin).
4. Run on an Android device or emulator (minimum Android 6.0 / API 23).
5. To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Before a public launch
Add a secure backend, OTP/authentication, encrypted transport, database access rules, real-time video provider, reporting/blocking, age assurance, consent flows, privacy policy, terms, grievance contact, moderation, payment provider and legally reviewed payout/tax workflows. Never collect sensitive ID documents until secure storage and access controls are implemented.
